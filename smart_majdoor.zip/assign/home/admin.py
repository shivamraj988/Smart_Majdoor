from django.contrib import admin
from home.models import CreateUser,Users
# Register your models here.
admin.site.register(Users)
admin.site.register(CreateUser)