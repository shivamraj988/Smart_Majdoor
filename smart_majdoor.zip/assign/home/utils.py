# users/utils.py
import string
import random

def generate_auto_id():
    prefix = 'SMj'
    suffix = ''.join(random.choices(string.digits, k=5))
    return f"{prefix}{suffix}"
