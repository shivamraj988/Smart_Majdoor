# users/forms.py
from django import forms
from .models import CreateUser

class UserForm(forms.ModelForm):
    class Meta:
        model = CreateUser
        fields = '__all__'

class YourModelForm(forms.ModelForm):
    class Meta:
        model = CreateUser
        fields = ['password']
        widgets = {
            'password': forms.PasswordInput(),
        }

class SignInForm(forms.Form):
    m_id = forms.CharField(max_length=150)
    password = forms.CharField(widget=forms.PasswordInput)


class CustomerSignUpForm(forms.Form):
    username=forms.CharField(max_length=50)
    password=forms.CharField(widget=forms.PasswordInput)
    name = forms.CharField(max_length=100)
    aadhar_no = forms.CharField(max_length=12)


