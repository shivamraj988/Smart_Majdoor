from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from .forms import SignInForm, UserForm
from .models import CreateUser, Users

def index(request):
    return render(request, 'index.html')

def customer_afterlogin(request):
    return render(request, 'customer_afterlogin.html')

def guide(request):
    return render(request, 'guide.html')

def about(request):
    return render(request, 'about.html')

def feedback(request):
    return render(request, 'feedback.html')


from django.shortcuts import render, redirect
from django.contrib import messages
from .models import CreateUser
from .forms import SignInForm

def majdoor_login(request):
    if request.method == 'POST':
        form = SignInForm(request.POST)
        if form.is_valid():
            m_id = form.cleaned_data['m_id']
            password = form.cleaned_data['password']

            # Authenticate user
            try:
                user = CreateUser.objects.get(m_id=m_id)
                if user.password == password:
                    # Authentication successful
                    # You can perform additional actions here if needed
                    # For example, you might want to set session variables
                    # or redirect the user to a different page
                    return redirect('majdoor_afterlogin')
                else:
                    # Password doesn't match
                    messages.error(request, 'Invalid password. Please try again.')
            except CreateUser.DoesNotExist:
                # User not found
                messages.error(request, 'User with provided ID does not exist.')

    else:
        form = SignInForm()

    return render(request, 'majdoor_login.html', {'form': form})




def majdoor_afterlogin(request, m_id):
    return render(request, 'majdoor_afterlogin.html', {'m_id': m_id})

def contact(request):
    return render(request, 'contact.html')

def customer_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        if username and password:
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('customer_afterlogin')
            else:
                error_message = "Invalid username or password."
                return render(request, 'customer_login.html', {'error_message': error_message})
        else:
            error_message = "Please provide both username and password."
            return render(request, 'customer_login.html', {'error_message': error_message})
    else:
        return render(request, 'customer_login.html')

from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from .forms import CustomerSignUpForm  # Import the CustomerSignUpForm

def customer_sign_up(request):
    if request.method == 'POST':
        form = CustomerSignUpForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            name = form.cleaned_data['name']
            aadhar_no = form.cleaned_data['aadhar_no']

            if User.objects.filter(username=username).exists():
                return render(request, 'customer_sign_up.html', {'form': form, 'error': 'Username already exists'})
            
            user = User.objects.create_user(username=username, password=password)
            user.name = name
            user.aadhar_no = aadhar_no
            user.save()
            return redirect('thank')
    else:
        form = CustomerSignUpForm()
    return render(request, 'customer_sign_up.html', {'form': form})


def forget(request):
    return render(request, 'forget.html')

def CreateUser(request):
    if request.method == 'POST':
        form = UserForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('thank')  
    else:
        form = UserForm()
    return render(request, 'create_user.html', {'form': form})

def thank(request):
    return render(request, 'thank.html')
